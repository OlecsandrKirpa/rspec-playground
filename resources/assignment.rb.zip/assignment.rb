RSpec.describe 'math calculations' do
  it 'does basic math' do
    expect(3 + 4).to eq(7)
    expect(10 - 5).to eq(5)
    expect(8 * 6).to eq(48)
    expect(20 / 2).to eq(10)
  end
end